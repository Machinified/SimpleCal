from string import find
from math import sqrt, factorial
from PySide.QtCore import SIGNAL, SLOT, Qt
from PySide.QtGui import QWidget, QVBoxLayout, QHBoxLayout, QLineEdit, QIcon, QFont, QPushButton, QToolButton, QStyle, QClipboard

class Screen(QWidget):
    def __init__(self, parent=None):
        QWidget.__init__(self, None)
        self.firstLine()
        self.secondLine()
        self.layout()
	    
        

    def layout(self):
        main = QVBoxLayout()
	main.setContentsMargins(1,1,1,1)
        self.setLayout(main)
        
        screenLayer = QVBoxLayout()
	screenLayer.setSpacing(0)
	screenLayer.setContentsMargins(1,2,1,1)
        screenLayer.addWidget(self.secLine)
        screenLayer.addWidget(self.fLine)

        buttonsLayer = QHBoxLayout()
	buttonsLayer.setSpacing(1)
        self.screenButtons = ['clear', 'backspace', 'copy']
	self.screenButtons[0] = QPushButton()
	self.screenButtons[0].setIcon(QIcon('icons/clear.svg'))
	self.screenButtons[0].setMinimumHeight(32)
	self.screenButtons[0].setMaximumWidth(45)
        self.screenButtons[1] = QPushButton()
	self.screenButtons[1].setMinimumHeight(32)
	self.screenButtons[1].setMaximumWidth(45)
        self.screenButtons[1].setIcon(QIcon('icons/bs.svg'))
        self.screenButtons[2] = QPushButton('Copy Screen')
	self.screenButtons[2].setMinimumHeight(32)
        self.screenButtons[2].setMinimumWidth(180)
	
        

        buttonsLayer.addWidget(self.screenButtons[2])
        buttonsLayer.addWidget(self.screenButtons[0])
        buttonsLayer.addWidget(self.screenButtons[1])
        
        main.addLayout(screenLayer)
        main.addLayout(buttonsLayer)

        ##Events
        self.connect(self.screenButtons[0], SIGNAL('clicked()'), self.fLine, SLOT('clear()'))
	self.connect(self.screenButtons[0], SIGNAL('clicked()'), self.secLine, SLOT('clear()'))
        self.connect(self.screenButtons[1], SIGNAL('clicked()'), self.fLine, SLOT('backspace()'))
        self.connect(self.screenButtons[2], SIGNAL('clicked()'), self, SLOT('copy_()'))
	self.connect(self.fLine, SIGNAL('returnPressed()'), self, SLOT('result()'))
        
    def secondLine(self):
        secLine = QLineEdit(self)
        secLine.setReadOnly(True)
        self.secLine = secLine
	secLine.setStyleSheet('background-color:white;border:1px top;')
       

    def firstLine(self):
        fLine = QLineEdit()
        fLine.setMinimumHeight(45)
        fLine.setAlignment(Qt.AlignRight)
        font = QFont('Ubuntu', 16)
        fLine.setFont(font)
        fLine.setText('0')
        fLine.setFocus()
        self.fLine = fLine
	fLine.setStyleSheet('background-color:white;border:0px 0px 0px 1px #ccc;')

    def copy_(self):
	onScreen = self.fLine.text()
        clipboard = QClipboard()
        clipboard.setText(onScreen)
        self.screenButtons[2].setText(str(onScreen))
	self.secLine.setText('Copied to clipboard')
	
    def insert_(self):
        txt = self.sender().text()
        if txt in '.0123456789':
	    """"""
	else:
	    txt = " " + txt + " "

	if self.fLine.text() == '0':
            self.fLine.setText(txt)
	else:
	    self.fLine.setText(self.fLine.text() + txt)


		

    def result(self):
	onScreen = self.fLine.text()	
	self.secLine.setText(str(onScreen) + ' =')
	if 'x' in onScreen:
	    place = find(onScreen, 'x')
	    if '.' in onScreen:
     		result = float(onScreen[:place]) * float(onScreen[place+1:])
	    else:
		result = int(onScreen[:place]) * int(onScreen[place+1:])
	elif '^' in onScreen:
	    place = string.find(onScreen, '^')
	    if '.' in onScreen:
		result = float(onScreen[:place]) ** float(onScreen[place+1:])          
	    else:
	        result =  int(onScreen[:place]) ** int(onScreen[place+1:])
	else:
	    result = eval(onScreen)	               
	self.fLine.setText(str(result))

    def squareroot(self):
	onScreen = self.fLine.text()
	if '.' in onScreen:
		result = sqrt(float(onScreen))
	else:
		result = sqrt(int(onScreen))
	self.secLine.setText("SQRT( " + str(onScreen) + " ) =")
	self.fLine.setText(str(result))

    def factorialFunc(self):
	onScreen = self.fLine.text()
	if '.' in onScreen:
		self.secLine.setText('Accepts Integral Values Only')
		result = None
	else:
		result = factorial(int(onScreen))
		self.secLine.setText("factorial( " + str(onScreen) + " ) =")
		self.fLine.setText(str(result))	   

	
