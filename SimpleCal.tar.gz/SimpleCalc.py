from screen import *
from sys import exit, argv
from PySide.QtGui import QApplication, QPalette, QColor


class Button(QPushButton):
    def __init__(self, parent=None, name= ' '):
        QPushButton.__init__(self, name)
        self.setMaximumWidth(45)
        self.setMinimumHeight(32)
        #self.setStyleSheet('background-color:transparent;color:white;')
	if name in ['x','%','n!','/','^','sqrt','+','-','(',')']:
	   pass
	   # self.setStyleSheet('background-color:#94C4E7;border-radius:21px;')
        if name == '=':
            self.setMinimumWidth(90)
            self.setDefault(True)
        


class Layer(QHBoxLayout):
    def __init__(self, parent=None):
        QHBoxLayout.__init__(self, None)



        
class App(QWidget):
    def __init__(self, parent=None):
        QWidget.__init__(self, None)
        #self.setStyleSheet("background-color:#034361;")
        self.setWindowTitle('Simple Calc 2')
        self.setWindowIcon(QIcon('icons/sc.svg'))
        self.layout()

    def layout(self):
        layouts = {}
        layouts['Main'] = QVBoxLayout()
	layouts['Main'].setSpacing(0)
        self.setLayout(layouts['Main'])
        ## Screen
        screen = Screen()
        layouts['screen'] = QVBoxLayout()
        layouts['screen'].addWidget(screen)
        ## Top Layout
        layouts['top'] = Layer()
        layouts['top'].addLayout(layouts['screen'])
        layouts['Main'].addLayout(layouts['top'])       
        ## Buttons
        line1 = ['7','8','9','/','sqrt','n!']
        line2 = ['4','5','6','x','(',')']
        line3 = ['1','2','3','-','^','%']
        line4 = ['0','.',' ','+','=']
        layouts['line1'] = Layer()
        layouts['Main'].addLayout(layouts['line1'])
        layouts['line2'] = Layer()
        layouts['Main'].addLayout(layouts['line2'])
        layouts['line3'] = Layer()
        layouts['Main'].addLayout(layouts['line3'])
        layouts['line4'] = Layer()
        layouts['Main'].addLayout(layouts['line4'])
        for i in range(len(line1)):
                 line1[i] = Button(name='%s' % line1[i])
                 layouts['line1'].addWidget(line1[i])
        for i in range(len(line2)):
                 line2[i] = Button(name='%s' % line2[i])
                 layouts['line2'].addWidget(line2[i])
        for i in range(len(line3)):
                 line3[i] = Button(name='%s' % line3[i])
                 layouts['line3'].addWidget(line3[i])
        for i in range(len(line4)):
                 line4[i] = Button(name='%s' % line4[i])
                 layouts['line4'].addWidget(line4[i])
        ##events
        self.connect(line4[4], SIGNAL('clicked()'), screen, SLOT('result()'))
        self.connect(line1[4], SIGNAL('clicked()'), screen, SLOT('squareroot()'))
        self.connect(line1[5], SIGNAL('clicked()'), screen, SLOT('factorialFunc()'))
        lines = [line1[:4],line2,line3,line4[:4]]
        for i in range(len(lines)):
            for j in range(len(lines[i])):
                self.connect(lines[i][j], SIGNAL('clicked()'), screen, SLOT('insert_()'))
        


if __name__ == '__main__':
    app = QApplication(argv)
    cal = App()
    cal.show()

    app.exec_()
    exit
